# Overview
I built this package as both an exercise and as a tool I hope to use into the future.

## PandasWrappers
Contains tools for manipulating data frames and extending functionality in ways I believe will be continuously helpful for me.